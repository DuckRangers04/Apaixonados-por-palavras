-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 13-Jul-2022 às 21:04
-- Versão do servidor: 10.4.24-MariaDB
-- versão do PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `apaix_por_pa`
--
CREATE DATABASE IF NOT EXISTS `apaix_por_pa` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `apaix_por_pa`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `nomliv` varchar(60) NOT NULL,
  `aut` varchar(70) NOT NULL,
  `sinop` varchar(1000) NOT NULL,
  `quant` int(2) NOT NULL,
  `capa` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `books`
--

INSERT INTO `books` (`id`, `nomliv`, `aut`, `sinop`, `quant`, `capa`) VALUES
(15, 'tetse', 'teste', 'testando', 1, 'capas/62cef33b8e974.jpg'),
(16, 'teste', 'teste', 'teste', 1, 'capas/62cef7e1cdb00.jpg'),
(17, 'Revolução dos iBchos', 'George Orwell', 'Revolta.', 1, 'capas/62cf0f73dd378.jpg'),
(18, 'Harry Potter ', 'J.K. Rolling', 'Magia, porrada, assassinato.', 1, 'capas/62cf14aa00f30.jpg');

-- --------------------------------------------------------

--
-- Estrutura da tabela `historic`
--

CREATE TABLE `historic` (
  `matri` int(7) NOT NULL,
  `nam_book` varchar(80) NOT NULL,
  `dat_ini_emp` date DEFAULT NULL,
  `dat_fin_emp` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `historic`
--

INSERT INTO `historic` (`matri`, `nam_book`, `dat_ini_emp`, `dat_fin_emp`) VALUES
(4129794, 'She-ra', '2022-07-22', '2022-07-31'),
(1324212, 'Hora de Aventura', '2022-08-27', '2022-08-31');

-- --------------------------------------------------------

--
-- Estrutura da tabela `requests`
--

CREATE TABLE `requests` (
  `matri` int(7) NOT NULL,
  `nam_book` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `requests`
--

INSERT INTO `requests` (`matri`, `nam_book`) VALUES
(4567897, 'FODASE'),
(4567895, 'FODASE 2');

-- --------------------------------------------------------

--
-- Estrutura da tabela `user_adm`
--

CREATE TABLE `user_adm` (
  `matri` int(7) NOT NULL,
  `email_inst` varchar(80) NOT NULL,
  `pass` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `user_adm`
--

INSERT INTO `user_adm` (`matri`, `email_inst`, `pass`) VALUES
(4129794, 'pedro.henrique76@alu.ufc.br', '78951456%'),
(0, '', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `user_com`
--

CREATE TABLE `user_com` (
  `matri` int(7) NOT NULL,
  `email` varchar(25) NOT NULL,
  `pass` varchar(255) DEFAULT NULL,
  `fvrt` multilinestring DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `user_com`
--

INSERT INTO `user_com` (`matri`, `email`, `pass`, `fvrt`) VALUES
(6969696, 'cudecupcake@gmail.com', '$2y$10$zdMclmAyj2fkXoTWWyouiuG5BmWmTrmGgZFqdqYCXrqihszkn62yO', NULL),
(2011016, 'videviada@gmail.com', '$2y$10$5J9bRoaVpCN8tylXnZK9R.KgRC.OnTXTRNEbk.1/ycQ/kFHUhtX4q', NULL);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `user_com`
--
ALTER TABLE `user_com`
  ADD PRIMARY KEY (`email`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
